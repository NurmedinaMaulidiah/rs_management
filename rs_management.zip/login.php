<?php
session_start();// Memulai session untuk menyimpan info user setelah login
require 'config/koneksi.php';// Memanggil file koneksi ke database

if(isset($_POST['login'])){// Jika tombol login ditekan
    $user = $_POST['user'];// Ambil username dan password dari form
    $password = $_POST['password'];
// Cari user di database berdasarkan username
    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    $data = mysqli_fetch_assoc($query);// Ambil data user sebagai array

    if($data){// Jika user ditemukan

        if($password == $data['password']){// Jika user ditemukan
// Simpan info user ke session
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['nama'] = $data['nama'];
            $_SESSION['role'] = $data['role'];
// Tampilkan popup selamat datang
            echo "<script>
                    alert('Selamat datang, ".$data['nama']."!');
                  </script>";

            // Redirect sesuai role
            if($data['role'] == "admin"){
                echo "<script>window.location='admin/dashboard.php'</script>";
            }
            elseif($data['role'] == "staff"){
                echo "<script>window.location='staff/patients.php'</script>";
            }
            elseif($data['role'] == "dokter"){
                echo "<script>window.location='doctor/patients.php'</script>";
            }

        } else {//kalo salah tampilkan allert

            echo "<script>
                    alert('Username atau Password salah!');
                    window.location='login.php';
                  </script>";
        }

    } else {

        echo "<script>
                alert('Username & Password Tidak Terdaftar, Silahkan Registrasi!');
                window.location='login.php';
              </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style-login.css"><!-- CSS khusus halaman login -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <title>Login RS Management</title>
</head>
<body>

<div class="container" id="container">

    <!-- kiri : form login -->
    <div class="box login">
        <form method="post">
            <div class="logo">
                <img src="img/HealynLogo.png" alt="Logo RS" width="50%">
            </div>
<!-- Input username & password -->
            <input type="text" name="user" placeholder="Username" class="input" required autocomplete="off">
            <input type="password" name="password" placeholder="Password" class="input" required autocomplete="off">
 <!-- Tombol login -->
            <input type="submit" name="login" value="Login" class="submit"><br><br>
<!-- Menampilkan error jika ada -->
            <?php if(isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
        </form>
    </div>

    <!-- kanan : gradient + text -->
    <div class="box side-right">
        <div class="text-right">
            <h1>RS Management</h1>
            <p>(Silakan login dengan menggunakan username dan email yang telah didaftarkan)</p>

            <ul class="fitur">
                <li>✔ Manajemen Data Pasien</li>
                <li>✔ Pengelolaan Data Dokter</li>
                <li>✔ Rekam Medis Digital</li>
                <li>✔ Akses Admin, Staff, Dokter</li>
            </ul>
        </div>

    </div>

</div>

<!-- <script src="js/main.js"></script> -->
</body>
</html>