<?php
$host = "sql211.infinityfree.com";       // Host dari InfinityFree
$user = "if0_41513028";                  // Username database
$pass = "Liawiadina88";                  // Password database
$db   = "if0_41513028_rs_management";    // Nama database

// Membuat koneksi ke database dengan mysqli_connect, jika koneksi gagal, program akan berhenti dan menampilkan pesan error."
$conn = mysqli_connect($host, $user, $pass, $db);
// Mengecek apakah koneksi gagal
if(!$conn){
    die("Koneksi gagal: " . mysqli_connect_error());//kalo gagal  hentikan program dan tampilkan pesan error
}
?>